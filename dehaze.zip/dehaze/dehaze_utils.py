import os
import numpy as np
import cv2
from keras.layers import Layer

# --- Custom AODNetFusion Layer ---
class AODNetFusion(Layer):
    def call(self, inputs):
        K, I = inputs
        return K * I - K + 1.0

from keras.models import load_model
from keras.preprocessing.image import img_to_array, load_img
from skimage.metrics import peak_signal_noise_ratio as psnr, structural_similarity as ssim

IMG_HEIGHT = 256
IMG_WIDTH = 256

MODEL_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "../model/dehaze_model.h5"))
model = load_model(MODEL_PATH, compile=False, custom_objects={'AODNetFusion': AODNetFusion})

def enhance_image(img_arr):
    img = img_arr.copy()
    # Step 1: Soft gamma correction
    gamma = 1.07  # Slightly increased for mild brightening
    look_up = np.array([((i / 255.0) ** (1.0 / gamma)) * 255 for i in np.arange(0, 256)]).astype("uint8")
    img = cv2.LUT(img, look_up)
    # Step 2: Less aggressive contrast & brightness
    alpha = 1.10    # Reduced from 1.18 to make contrast enhancement softer
    beta = 5        # Reduced brightness
    img = cv2.convertScaleAbs(img, alpha=alpha, beta=beta)
    # Step 3: Mild edge blend
    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
    sobelx = cv2.Sobel(gray, cv2.CV_16S, 1, 0)
    sobely = cv2.Sobel(gray, cv2.CV_16S, 0, 1)
    # Reduce strength: blend weight lower than before
    edge_mask = cv2.addWeighted(cv2.convertScaleAbs(sobelx), 0.5, cv2.convertScaleAbs(sobely), 0.5, 0)
    edge_mask_rgb = cv2.cvtColor(edge_mask, cv2.COLOR_GRAY2RGB)
    img = cv2.addWeighted(img, 0.92, edge_mask_rgb, 0.17, 0)
    # Step 4: Gentle sharpening
    kernel = np.array([[0, -0.5, 0], [-0.5, 3, -0.5], [0, -0.5, 0]])  # Softer than before
    img = cv2.filter2D(img, -1, kernel)
    # Step 5: Vivid color, soft boost
    hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV).astype("float32")
    h, s, v = cv2.split(hsv)
    s = np.clip(s * 1.06, 0, 255)   # Less saturation boost
    v = np.clip(v * 1.04, 0, 255)   # Less brightness boost
    hsv = cv2.merge([h, s, v])
    final = cv2.cvtColor(hsv.astype("uint8"), cv2.COLOR_HSV2RGB)
    return np.clip(final, 0, 255).astype(np.uint8)

def calculate_metrics(original_path, dehazed_img):
    metrics = {}
    original_img = cv2.imread(original_path)
    if original_img is not None:
        original_img = cv2.cvtColor(original_img, cv2.COLOR_BGR2RGB)
        original_img = cv2.resize(original_img, (IMG_WIDTH, IMG_HEIGHT))
        metrics['PSNR'] = psnr(original_img, dehazed_img)
        metrics['SSIM'] = ssim(original_img, dehazed_img, channel_axis=2)
    return metrics

def dehaze_image(input_image_path, output_image_path):
    img = load_img(input_image_path, target_size=(IMG_HEIGHT, IMG_WIDTH))
    img_arr = img_to_array(img).astype(np.float32) / 255.0
    model_input = np.expand_dims(img_arr, axis=0)
    dehazed = np.clip(model.predict(model_input)[0], 0, 1)
    dehazed_uint8 = np.clip((dehazed * 255).round(), 0, 255).astype(np.uint8)
    enhanced_img = enhance_image(dehazed_uint8)
    cv2.imwrite(output_image_path, cv2.cvtColor(enhanced_img, cv2.COLOR_RGB2BGR))
    metrics = calculate_metrics(input_image_path, enhanced_img)
    return output_image_path, metrics
