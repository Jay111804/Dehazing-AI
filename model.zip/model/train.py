import os
import numpy as np
from tensorflow import keras
from keras.preprocessing.image import img_to_array, load_img
from keras.models import Model
from keras.layers import Input, Conv2D, Concatenate
from keras.optimizers import Adam
from sklearn.model_selection import train_test_split

IMG_HEIGHT, IMG_WIDTH = 256, 256

def load_images(img_folder):
    images = []
    for fname in sorted(os.listdir(img_folder)):
        path = os.path.join(img_folder, fname)
        img = load_img(path, target_size=(IMG_HEIGHT, IMG_WIDTH))
        img = img_to_array(img) / 255.0
        images.append(img)
    return np.array(images)

from keras.layers import Layer

class AODNetFusion(Layer):
    def call(self, inputs):
        K, I = inputs
        return K * I - K + 1.0  # This is J(x) = K(x) * I(x) - K(x) + 1

def build_aodnet(input_shape=(256,256,3)):
    from keras.layers import Input, Conv2D
    from keras.models import Model
    inputs = Input(shape=input_shape)
    conv1 = Conv2D(16, (3,3), activation='relu', padding='same')(inputs)
    conv2 = Conv2D(16, (3,3), activation='relu', padding='same')(conv1)
    conv3 = Conv2D(16, (3,3), activation='relu', padding='same')(conv2)
    conv4 = Conv2D(8, (3,3), activation='relu', padding='same')(conv3)
    conv5 = Conv2D(4, (3,3), activation='relu', padding='same')(conv4)
    K = Conv2D(3, (3,3), activation='sigmoid', padding='same')(conv5)
    J = AODNetFusion()([K, inputs])
    model = Model(inputs, J)
    return model

def main():
    print("Loading images...")
    hazy_imgs = load_images('data/raw')
    clean_imgs = load_images('data/clean')

    print("Splitting dataset...")
    X_train, X_val, y_train, y_val = train_test_split(hazy_imgs, clean_imgs, test_size=0.1, random_state=42)

    print(f"Training samples: {len(X_train)}, Validation samples: {len(X_val)}")
    model = build_aodnet()  # <-- Use AODNet now
    model.compile(optimizer=Adam(1e-4), loss='mean_squared_error', metrics=['mae'])
    model.summary()

    print("Training...")
    model.fit(X_train, y_train, batch_size=4, epochs=50, validation_data=(X_val, y_val))

    print("Saving model...")
    os.makedirs("model", exist_ok=True)
    model.save('model/dehaze_model.h5')
    print("Model saved to model/dehaze_model.h5")

if __name__ == '__main__':
    main()
